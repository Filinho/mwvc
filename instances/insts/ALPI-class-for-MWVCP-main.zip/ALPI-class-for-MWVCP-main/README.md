# ALPI-class-for-MWVCP
72 large scale instances are obtained from Network Data Repository with more than 1000 vertices for the MWVCP. 
